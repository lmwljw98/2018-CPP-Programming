// C++ BattleShip 프로젝트
// 작성 일자: 2018-05-31
// 학번 : 20171676
// 이름 : 이정우
#include "GameManager.h"

using namespace std;

int main(){
    GameManager game;
    game.play();
    return 0;
}
